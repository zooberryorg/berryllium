from django.shortcuts import render, redirect
from django.core.files.storage import default_storage
from django.views.decorators.http import require_http_methods
from django.http import HttpResponse
from django.views.generic import CreateView, TemplateView, FormView, UpdateView
from django.urls import reverse, reverse_lazy as lazy_reverse

from berryllium.mods.forms import (
    ModFileUploadForm,
    ModCategorizationForm,
    ModImageUploadForm,
    ModDescriptionForm,
    ModGeneralInfoForm,
)
from berryllium.mods.models import Mod, ModImage
from berryllium.mods.services import (
    init_context,
    upload_file,
    create_file_group,
    create_filegroup_formsets,
    upload_image,
)
from berryllium.mods.settings import UPLOAD_NAVIGATION

class ModDraftView(CreateView):
    """
    HTMX Endpoint: Create a draft mod and return its ID for session management.
    """

    model = Mod
    form_class = ModGeneralInfoForm
    template_name = "mods/create/draft.html"

    def get_success_url(self):
        """
        Override to prevent redirect since we handle navigation with HTMX.
        """
        return reverse("mod_create_landing", kwargs={"mod_id": self.object.id})

    def form_valid(self, form):
        """
        Create a new draft mod and return its ID in the response for session management.
        """
        response = super().form_valid(form)
        self.request.session["session_id"] = self.object.id
        response = HttpResponse()
        response["HX-Redirect"] = self.get_success_url()
        return response

class ModCreateLanding(TemplateView):
    """
    Mod Creation Landing Page: Serves as base template for multi-step mod creation process.
    """

    template_name = "mods/create/base.html"

    def get_success_url(self):
        """
        Override to prevent redirect since we handle navigation with HTMX.
        """
        return reverse("mod_create_general", kwargs={"mod_id": self.kwargs["mod_id"]})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["mod_navigation"] = UPLOAD_NAVIGATION
        context["mod_id"] = self.kwargs["mod_id"]
        return context

    # def get(self, request, *args, **kwargs):
    #     # Clear session later to start new
    #     # request.session.pop("session_id", None)
    #     # request.session.pop("group_manager_toggled", None)
    #     return redirect("mod_create_categorization")

class ModCreateGeneralInfo(UpdateView):
    """
    Mod Creation Multi-Step 0: General Information (Title, Summary, etc.)
    """

    model = Mod
    form_class = ModGeneralInfoForm
    template_name = "mods/create/general/base.html"

    def get_success_url(self):
        """
        Override to prevent redirect since we handle navigation with HTMX.
        """
        return reverse("mod_create_categorization", kwargs={"mod_id": self.object.id})
    
    def get_object(self, queryset=None):
        mod_id = self.request.session.get("session_id")
        return Mod.objects.get(id=mod_id)
    
    def form_valid(self, form):
        """
        Validate form and save draft mod, then store mod ID in session for later steps.
        """
        response = super().form_valid(form)
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        progress_bar = init_context(current_index=0)
        mod_id = self.request.session.get("session_id")
        context["mod_id"] = mod_id
        return context | progress_bar
    
    def get_form_kwargs(self):
        """
        Re-hydrate form with existing draft data if session exists.
        """
        kwargs = super().get_form_kwargs()
        session_id = self.request.session.get("session_id")
        if session_id:
            try:
                kwargs["instance"] = Mod.objects.get(id=session_id)
            except Mod.DoesNotExist:
                pass
        return kwargs

class ModCreateCategorization(UpdateView):
    """
    Mod Creation Multi-Step 1: Select Categories and Create Draft Mod
    """

    model = Mod
    form_class = ModCategorizationForm
    template_name = "mods/create/categorization/base.html"
    success_url = lazy_reverse("mod_create_files")

    def form_valid(self, form):
        """
        Validate form and save draft mod, then store mod ID in session for later steps.
        """
        response = super().form_valid(form)
        self.request.session["session_id"] = self.object.id
        return response
    
    def get_object(self, queryset=None):
        mod_id = self.request.session.get("session_id")
        return Mod.objects.get(id=mod_id)

    def get_context_data(self, **kwargs):
        """
        Get context data for rendering the form, including progress bar information.
        """
        context = super().get_context_data(**kwargs)
        progress_bar = init_context(current_index=1)
        return context | progress_bar

    def get_form_kwargs(self):
        """
        Re-hydrate form with existing draft data if session exists.
        """
        kwargs = super().get_form_kwargs()
        session_id = self.request.session.get("session_id")
        if session_id:
            try:
                kwargs["instance"] = Mod.objects.get(id=session_id)
            except Mod.DoesNotExist:
                pass
        return kwargs


class ModCreateFiles(FormView):
    """
    Mod Creation Multi-Step 2: Upload Files and Organize into File Groups
    """

    form_class = ModFileUploadForm
    template_name = "mods/create/filemanager/base.html"
    success_url = lazy_reverse("mod_create_images")

    def get_context_data(self, **kwargs):
        """
        Get context data for rendering the form, including existing uploaded files and progress bar information.
        """
        context = super().get_context_data(**kwargs)
        progress_bar = init_context(current_index=2)

        mod_id = self.request.session.get("session_id")
        existing_files = []
        existing_filegroups = []

        if mod_id:
            mod = Mod.objects.get(id=mod_id)
            files = mod.files.all()

            # make formsets for existing file groups to render in template
            file_group_forms, filegroups, group_formset = create_file_group(mod_id)
            ModFileGroupFormset, ModFileFormset = create_filegroup_formsets()
            group_formset = ModFileGroupFormset(queryset=filegroups)

            if files.exists():
                existing_files = [f for f in files.values("filename", "size", "id")]
                context["existing_files"] = existing_files
            if filegroups.exists():
                existing_filegroups = filegroups.values("name", "id")
                print("Existing file groups:", existing_filegroups)
                context["file_groups"] = file_group_forms
                context["group_formset"] = group_formset

        return context | progress_bar

    def form_valid(self, form):
        """
        Handle file upload, save to storage, and re-render form with updated file list.
        """
        clean_file = form.cleaned_data["file"]
        mod_id = self.request.session.get("session_id")
        print(
            "form_valid called with file:",
            clean_file and clean_file.name,
            "and mod_id:",
            mod_id,
        )
        if clean_file:
            print("Attempting to upload file:", clean_file.name)
            file = upload_file(clean_file, mod_id=mod_id)
            if file:
                print("File uploaded successfully:", file)
                # re-render form with new file included in existing_files
                existing_files = self.get_context_data().get("existing_files", [])
                context = self.get_context_data()
                context["existing_files"] = existing_files
                return render(self.request, self.template_name, context)
            else:
                print("Failed to upload file:", clean_file.name)
        else:
            print("No file uploaded or file failed validation.")

        return super().form_valid(form)

    def get_success_url(self):
        """
        Handle navigation based on which button was clicked (Next vs Previous).
        """
        action = self.request.POST.get("action") == "previous"
        if action == "previous":
            return lazy_reverse("mod_create_categorization")
        elif action == "uploaded_file":
            return self.request.path
        return super().get_success_url()


class ModCreateImages(FormView):
    """
    Mod Creation Multi-Step 3: Upload Pictures for the Mod
    """

    form_class = (
        ModImageUploadForm  # Placeholder, replace with actual picture upload form
    )
    template_name = "mods/create/pictures/base.html"
    success_url = "/mods/create/images"

    def get_context_data(self, **kwargs):
        """
        Get context data for rendering the form, including progress bar information.
        """
        context = super().get_context_data(**kwargs)
        progress_bar = init_context(current_index=3)

        # get images for current mod from session
        mod_id = self.request.session.get("session_id")
        if mod_id:
            context["images"] = ModImage.objects.filter(mod_id=mod_id).values(
                "id", "caption", "title", "image", "is_cover"
            )

        return context | progress_bar

    def form_valid(self, form):
        """
        Handle uploads and other validations
        """
        # get images from form and save to storage, associate with mod, etc.
        uploaded_images = form.cleaned_data.get("image")
        mod_id = self.request.session.get("session_id")
        print("form_valid called with images:", uploaded_images, "and mod_id:", mod_id)
        if uploaded_images:
            for img in uploaded_images:
                file = upload_image(img, mod_id=mod_id)
                if file:
                    print("Image uploaded successfully:", file["name"])

        context = self.get_context_data()
        context["images"] = ModImage.objects.filter(mod_id=mod_id).values(
            "id", "title", "caption", "image"
        )

        return super().form_valid(form)


class ModCreateDescription(UpdateView):
    """
    Mod Creation Multi-Step 4: Add Description.
    """

    model = Mod
    form_class = ModDescriptionForm
    template_name = "mods/create/description/base.html"
    success_url = "/mods/create/s4"

    def get_object(self, queryset=None):
        mod_id = self.request.session.get("session_id")
        return Mod.objects.get(id=mod_id)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        progress_bar = init_context(current_index=4)

        return context | progress_bar


def upload_step3(request):

    return render(
        request,
        "mods/create/step/3.html",
        context=init_context(current_index=3, form=None),
    )


# TODO: Fix latency issues with HX requests (takes forever between initial upload and response)
@require_http_methods(["POST"])
def remove_temp_file(request, file_id):
    """
    Delete a file from current session.
    """
    mod_id = request.session.get("session_id")
    if request.method == "POST":
        mod = Mod.objects.filter(id=mod_id).first()
        temp_files = mod.files.all() if mod else []

        # find file by id in temp_files
        file = temp_files.filter(id=file_id).first()
        temp_path = []
        if file:
            file.delete()
            temp_path = file.staged_file.path

        # Delete from storage (in case row was missing)
        if temp_path and default_storage.exists(temp_path):
            default_storage.delete(temp_path)

        return HttpResponse(status=204)


@require_http_methods(["POST"])
def cancel_mod_upload(request):
    """
    Cancel and delete the current mod upload session.
    Note: live version will only delete session data. Live version
    will keep draft and temp files until a cleanup task runs,
    the mod is processed into a full mod, or the user manually deletes the draft.
    """
    mod_id = request.session.get("session_id")
    if mod_id:
        # Get all files with this session
        mod = Mod.objects.filter(id=mod_id).first()
        if mod:
            files = mod.files.all()
            for f in files:
                # Delete file from storage
                if f.staged_file and default_storage.exists(f.staged_file.name):
                    default_storage.delete(f.staged_file.name)
            # Delete session directory if it exists
            session_dir = f"temp_uploads/{mod_id}/"
            if default_storage.exists(session_dir):
                default_storage.delete(session_dir)
            # Delete draft mod
            mod.delete()

        # Clear session data related to the upload
        request.session.pop("session_id", None)
        request.session.modified = True

    # force htmx to redirect instead of trying to re-render
    response = HttpResponse()
    response["HX-Redirect"] = redirect("home").url
    return response
