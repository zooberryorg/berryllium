function createModal() {
    return {
        // modal closed by default
        isOpen: false,
        modalTitle: "Modal Title",
        endpoint: "",
        icon: "",

        openModal(detail = {}) {
            this.isOpen = true;
            this.endpoint = detail.endpoint || "";
            this.modalTitle = detail.modalTitle || "Modal Title";
            this.icon = detail.icon || "";
            this.maxWidth = detail.maxWidth || "max-w-2xl";
            this.hideHeader = detail.hideHeader || false;
            this.focusAfterRender = detail.focusAfterRender || null;

            // HTMX for form content
            setTimeout(() => {
                const modalContent = document.getElementById('modal-content');
                if (modalContent) {
                    htmx.ajax('GET', this.endpoint, { target: '#modal-content', swap: 'innerHTML' });
                }
            }, 100);
        },

        closeModal() {
            console.log("focusAfterRender:", this.focusAfterRender);
            this.focusAfterRender?.firstElementChild?.scrollIntoView({ behavior: 'smooth' });
            this.isOpen = false;
            // clear modal content
            const contentDiv = document.getElementById('modal-content');
            if (contentDiv) {
                contentDiv.innerHTML = '<div class="text-white/70">Loading...</div>';
            }
        }
    }
}